package ObjectRepository;

public class Configuration {
	
	 //TestSite URL and selected Browser
    public static final String testsite = "http://automationpractice.com/index.php";
    public static final String browser = "firefox";
    

    //LandingPage
    public static final String signin_class = "login";

    //LoginPage
    public static final String email_id = "email";
    public static final String password_id = "passwd";
    public static final String signinBtn_id = "SubmitLogin";
    
    //HomePage
    public static final String womenLink_class = "sf-with-ul";
    
    //WomenPage
    public static final String tShirt_xpath = "/html/body/div/div[2]/div/div[3]/div[2]/ul/li[1]/div/div[1]/div/a[1]/img";
    
    //TShirtPage
    public static final String showPrice_id = "our_price_display";
    public static final String addToCart_xpath = "/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[3]/div/p/button/span";
   
    
    //CartPage
    public static final String cartTotal_class = "ajax_block_products_total";
    public static final String proceedToCheckOut_xpath = "/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/a";
    
    //CheckOutPage
    public static final String delete_id = "1_1_0_337721";
    
    
    

}
