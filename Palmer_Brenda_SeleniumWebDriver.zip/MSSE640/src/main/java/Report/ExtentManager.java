package Report;

import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {
	
	private static com.relevantcodes.extentreports.ExtentReports filename ;

    public synchronized static ExtentReports getReporter(){

        if(filename == null){

            //Set HTML reporting file location
            String workingDir = System.getProperty("user.dir") + "/test-output/testReport.html";
            System.out.println(workingDir);
            filename = new com.relevantcodes.extentreports.ExtentReports(workingDir, true);

        }

        return filename;
    }

}
