package TestCases;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Utilities.DriverManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest extends DriverManager{




    public static WebDriver driver = null;
    public static final ThreadLocal<WebDriver> dr = new ThreadLocal<WebDriver>();

    private FileInputStream fis;


    public BaseTest() {


    }

    @BeforeClass
    public void setUp(){



        if (ObjectRepository.Configuration.browser.equals("firefox")) {
            System.out.println("setUP Configure Firefox");
            WebDriverManager.firefoxdriver().setup();



        } else {
            System.out.println("setUP Configure Chrome");
            WebDriverManager.chromedriver().setup();


        }


        getDriverInstance();

    }

    private WebDriver getDriverInstance() {

        String url = ObjectRepository.Configuration.testsite;

        if (ObjectRepository.Configuration.browser.equals("firefox")) {

            System.out.println("getDriverInstance Firefox");
            driver = new FirefoxDriver();

        } else {
            System.out.println("getDriverInstance Chrome");
            driver = new ChromeDriver();
        }



        driver.navigate().to(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);


        return driver;
    }





    @AfterClass
    public void teardown(){
    driver.quit();
    }


}//end of class