package TestCases;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Pages.CartPage;
import Pages.CheckOutPage;
import Pages.HomePage;
import Pages.LandingPage;
import Pages.LoginPage;
import Pages.TShirtPage;
import Pages.WomenPage;
import Report.ExtentTestManager;

public class ShoppingTest extends BaseTest{
	
	@Test
	public void ShoppingTest1() throws InterruptedException {
		
		ExtentTestManager.getTest().setDescription("Verifing I can log into the application, add an item to the shopping cart, check the price and remove the item from the cart");
		ExtentTestManager.getTest().assignAuthor("Brenda Palmer");
		
		LandingPage landingPage = PageFactory.initElements(driver, LandingPage.class);
		landingPage.actionSignin();
		
				
		LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
		loginPage.actionEmail();
		loginPage.actionPassword();
		loginPage.actionsigninBtn();
		
		HomePage homePage = PageFactory.initElements(driver, HomePage.class);
		homePage.actionWomenLink();
		
		
		WomenPage womenPage = PageFactory.initElements(driver, WomenPage.class);
		womenPage.actiontShirt();
		
		
		TShirtPage tShirtPage = PageFactory.initElements(driver, TShirtPage.class);
		tShirtPage.actionshowPrice();
		tShirtPage.actionaddToCart();
	
		Thread.sleep(7000);
		
		CartPage cartPage = PageFactory.initElements(driver, CartPage.class);
		cartPage.actioncartTotal();
		cartPage.actionproceedToCheckOut();
		
		
		CheckOutPage checkOutPage = PageFactory.initElements(driver, CheckOutPage.class);
		checkOutPage.actiondelete();
		
		
	}

}
