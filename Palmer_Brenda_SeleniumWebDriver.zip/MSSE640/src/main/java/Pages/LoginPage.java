package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends BasePage {
	
	WebDriver driver;
	
	public LoginPage() {
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(id = ObjectRepository.Configuration.email_id)
	public WebElement email;
	
	public void actionEmail() {
		
		String value = "me@aol.com";
		
		type(email, value, "Entering email to login");
	}

	@FindBy(id = ObjectRepository.Configuration.password_id)
	public WebElement password;
	
	public void actionPassword() {
		
		String value = "test1234";
		
		type(password, value, "Entering password for sign in");
	}
	
	@FindBy(id = ObjectRepository.Configuration.signinBtn_id)
	public WebElement signinBtn;
	
	public void actionsigninBtn() {
		
		click(signinBtn, "Clicking on Sign In button");
	}
	

	

}
