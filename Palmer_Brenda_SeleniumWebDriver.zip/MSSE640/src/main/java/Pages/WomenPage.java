package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WomenPage extends BasePage{

	WebDriver driver;
	
	public WomenPage() {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = ObjectRepository.Configuration.tShirt_xpath)
	public WebElement tShirt;
	
	public void actiontShirt() {
		
		click(tShirt, "Clicking on T-Shirt to view more detail");
	}
}
