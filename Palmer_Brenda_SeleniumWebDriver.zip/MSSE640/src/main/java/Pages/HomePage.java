package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends BasePage{
	
	WebDriver driver;
	
	public HomePage() {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className = ObjectRepository.Configuration.womenLink_class)
	public WebElement womenLink;
	
	public void actionWomenLink() {
		
		click(womenLink, "Clicking on the Women link");
	}

}
