package Pages;

import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.LogStatus;

import Report.ExtentTestManager;

public class BasePage {
	
	 public BasePage(){}


	    public void click(WebElement element, String elementName){

	        element.click();
	        ExtentTestManager.getTest().log(LogStatus.INFO, elementName);

	    }

	    public void isDisplayed(WebElement element, String elementName){

	        ExtentTestManager.getTest().log(LogStatus.INFO, elementName);

	    }

	    public void isChecked(WebElement element, String elementName){

	        ExtentTestManager.getTest().log(LogStatus.INFO, elementName);

	    }



	    public BasePage type(WebElement element, String value, String elementName){

	        element.sendKeys(value);
	        ExtentTestManager.getTest().log(LogStatus.INFO, "Entered the value as: " + value + " " + elementName);
	        return this;
	    }

}
