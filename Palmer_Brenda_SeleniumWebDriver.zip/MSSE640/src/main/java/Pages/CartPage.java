package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import Report.ExtentTestManager;

public class CartPage extends BasePage{
	
	WebDriver driver;
	
	public CartPage() {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className = ObjectRepository.Configuration.cartTotal_class)
	public WebElement cartTotal;
	
	public void actioncartTotal() {
		
		//to really verify this value to the item price before it was added to the cart I could return the price value and then compare
		String desireValue = "$16.51";
		
		String value = cartTotal.getText();
		
		if(value.equals(desireValue)) {
			
			ExtentTestManager.getTest().log(LogStatus.PASS, "Price in cart matches price of item");
		}else {
			
			ExtentTestManager.getTest().log(LogStatus.FAIL, "Price in cart does NOT match price of item");
		}
		
	}
	
	@FindBy(xpath = ObjectRepository.Configuration.proceedToCheckOut_xpath)
	public WebElement proceedToCheckOut;
	
	public void actionproceedToCheckOut() {
		
		click(proceedToCheckOut, "Clicking on Proceed to Checkout button");
	}

}
