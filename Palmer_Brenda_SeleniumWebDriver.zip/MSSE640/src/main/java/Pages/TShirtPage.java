package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import Report.ExtentTestManager;

public class TShirtPage extends BasePage{
	
	WebDriver driver;
	
	public TShirtPage() {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = ObjectRepository.Configuration.showPrice_id)
	public WebElement showPrice;
	
	public void actionshowPrice() {
		
		String desiredValue = "$16.51";		
		
		String value = showPrice.getText();
		
		if(value.equals(value)) {
			
			ExtentTestManager.getTest().log(LogStatus.PASS, "This is the price displayed for the t-shirt " + value);
		}else {
			
			ExtentTestManager.getTest().log(LogStatus.FAIL, "Incorrect price is displayed for the t-shirt");
		}
	}
	
	@FindBy(xpath = ObjectRepository.Configuration.addToCart_xpath)
	public WebElement addToCart;
	
	public void actionaddToCart() {
		
		click(addToCart, "Adding T-Shirt to the cart");
	}
}
