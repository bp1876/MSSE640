package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckOutPage extends BasePage{
	
	WebDriver driver;
	
	public CheckOutPage() {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = ObjectRepository.Configuration.delete_id)
	public WebElement delete;
	
	public void actiondelete() {
		
		click(delete, "Removing T-Shirt from the cart");
	}

}
