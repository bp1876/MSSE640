package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandingPage extends BasePage{
	
	WebDriver driver;
	
	public LandingPage() {
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}

	@FindBy (className = ObjectRepository.Configuration.signin_class)
	public WebElement signin;
	
	public void actionSignin() {
		
		click(signin, "Clicking on Sign In link on Landing Page");
	}
	
}
