/**
 * 
 */
package Utilities;

import org.openqa.selenium.WebDriver;

/**
 * @author Brenda Palmer
 *
 */
public class DriverManager {
	
	public static final ThreadLocal<WebDriver> dr = new ThreadLocal<WebDriver>();
	
	public static WebDriver getDriver() {
		
		return dr.get();
	}
	
public static final void setWebDriver(WebDriver driver) {
	
	dr.set(driver);
}

}
